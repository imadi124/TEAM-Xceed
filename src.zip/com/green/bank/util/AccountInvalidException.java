package com.green.bank.util;

public class AccountInvalidException extends Exception {
	public AccountInvalidException(String message) {
		super(message);
	}
}
