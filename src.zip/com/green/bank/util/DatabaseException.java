package com.green.bank.util;

public class DatabaseException extends Exception {

	public DatabaseException(String message) {
		super(message);
	}
}
