package com.green.bank;

public class LoanServletTest {

}
